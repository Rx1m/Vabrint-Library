local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local Camera = workspace.CurrentCamera

local LocalPlayer = Players.LocalPlayer

local ESP = {
    Enabled = false,
    ShowBoxes = true,
    ShowNames = true,
    ShowTracers = true,
    ShowHealth = true,

    ColorMode = "rgb",
    CustomColor = Color3.new(1,1,1),

    HealthColorMode = "match",
    HealthCustomColor = Color3.new(0,1,0),

    TextSize = 16,
    BoxThickness = 2,
    TracerThickness = 1,
}

local espObjects = {}

local function hexToColor3(hex)
    hex = hex:gsub("#","")
    if #hex ~= 6 then return Color3.new(1,1,1) end
    local r = tonumber(hex:sub(1,2),16)/255
    local g = tonumber(hex:sub(3,4),16)/255
    local b = tonumber(hex:sub(5,6),16)/255
    return Color3.new(r,g,b)
end

local function parseColorMode(mode)
    if mode:lower() == "rgb" then
        return "rgb", nil
    elseif mode:sub(1,7):lower() == "custom," then
        local hex = mode:sub(8)
        return "custom", hexToColor3(hex)
    else
        return "rgb", nil
    end
end

local function newDrawing(t, props)
    local obj = Drawing.new(t)
    for k,v in pairs(props) do obj[k] = v end
    return obj
end

local function createESPElements()
    return {
        Box = newDrawing("Square", {Visible=false,Thickness=ESP.BoxThickness,Filled=false,Color=Color3.new(1,1,1)}),
        Name = newDrawing("Text",   {Visible=false,Center=true,Outline=true,Size=ESP.TextSize,Font=2,Color=Color3.new(1,1,1)}),
        Tracer = newDrawing("Line", {Visible=false,Thickness=ESP.TracerThickness,Color=Color3.new(1,1,1)}),
        HealthBar = newDrawing("Line", {Visible=false,Thickness=4,Color=Color3.new(0,1,0)})
    }
end

local function getRainbowColor(t)
    local f=2
    return Color3.new(math.sin(f*t)*.5+.5,math.sin(f*t+2)*.5+.5,math.sin(f*t+4)*.5+.5)
end

local function getBoxScreenPoints(cf,size)
    local half=size/2
    local pts,vis={},true
    for x=-1,1,2 do for y=-1,1,2 do for z=-1,1,2 do
        local c=cf*Vector3.new(half.X*x,half.Y*y,half.Z*z)
        local sp,on=Camera:WorldToViewportPoint(c)
        if not on then vis=false end
        pts[#pts+1]=Vector2.new(sp.X,sp.Y)
    end end end
    return pts,vis
end

local function hideAll(d)
    d.Box.Visible=false
    d.Name.Visible=false
    d.Tracer.Visible=false
    d.HealthBar.Visible=false
end

function ESP:SetColorMode(m)
    local cm,c=parseColorMode(m)
    self.ColorMode=cm
    if c then self.CustomColor=c end
end

function ESP:SetHealthColorMode(m)
    local cm,c=parseColorMode(m)
    self.HealthColorMode=cm
    if c then self.HealthCustomColor=c end
end

function ESP:SetShowBoxes(v) self.ShowBoxes=v end
function ESP:SetShowNames(v) self.ShowNames=v end
function ESP:SetShowTracers(v) self.ShowTracers=v end
function ESP:SetShowHealth(v) self.ShowHealth=v end
function ESP:SetTextSize(v) self.TextSize=v end
function ESP:SetBoxThickness(v) self.BoxThickness=v end
function ESP:SetTracerThickness(v) self.TracerThickness=v end

function ESP:Enable() self.Enabled=true end
function ESP:Disable()
    self.Enabled=false
    for _,d in pairs(espObjects) do hideAll(d) end
end

RunService.RenderStepped:Connect(function()
    if not ESP.Enabled then return end
    local t=tick()
    local col=ESP.ColorMode=="rgb" and getRainbowColor(t) or ESP.CustomColor
    local ctr=Vector2.new(Camera.ViewportSize.X/2,Camera.ViewportSize.Y)
    for _,p in ipairs(Players:GetPlayers()) do
        if p~=LocalPlayer then
            local c=p.Character
            local h=c and c:FindFirstChildOfClass("Humanoid")
            if c and h and h.Health>0 then
                local ok,cf,sz=pcall(c.GetBoundingBox,c)
                if ok and cf and sz then
                    local pts,vis=getBoxScreenPoints(cf,sz)
                    if not vis then if espObjects[p] then hideAll(espObjects[p]) end goto cont end
                    local d=espObjects[p] or createESPElements()
                    espObjects[p]=d
                    local minX,minY, maxX,maxY=1e9,1e9,-1e9,-1e9
                    for _,pt in ipairs(pts) do
                        minX,minY=math.min(minX,pt.X),math.min(minY,pt.Y)
                        maxX,maxY=math.max(maxX,pt.X),math.max(maxY,pt.Y)
                    end
                    local w,h=maxX-minX, maxY-minY
                    local sw=w*0.7
                    local sx=minX+(w-sw)/2
                    local hr=math.clamp(h.Health/h.MaxHealth,0,1)
                    if ESP.ShowBoxes then
                        d.Box.Visible=true; d.Box.Position=Vector2.new(sx,minY)
                        d.Box.Size=Vector2.new(sw,h)
                        d.Box.Thickness=ESP.BoxThickness
                        d.Box.Color=col
                    else d.Box.Visible=false end
                    if ESP.ShowNames then
                        d.Name.Visible=true; d.Name.Text=p.Name
                        d.Name.Position=Vector2.new(sx+sw/2,minY-20)
                        d.Name.Size=ESP.TextSize
                        d.Name.Color=col
                    else d.Name.Visible=false end
                    if ESP.ShowTracers then
                        d.Tracer.Visible=true; d.Tracer.From=ctr
                        d.Tracer.To=Vector2.new(sx+sw/2,maxY)
                        d.Tracer.Thickness=ESP.TracerThickness
                        d.Tracer.Color=col
                    else d.Tracer.Visible=false end
                    if ESP.ShowHealth then
                        local bh=h.* hr
                        d.HealthBar.Visible=true; d.HealthBar.From=Vector2.new(sx-6,maxY)
                        d.HealthBar.To=Vector2.new(sx-6,maxY-bh)
                        d.HealthBar.Thickness=4
                        d.HealthBar.Color=(ESP.HealthColorMode=="match" and col or ESP.HealthCustomColor)
                    else d.HealthBar.Visible=false end
                end
            else
                if espObjects[p] then hideAll(espObjects[p]) end
            end
        end
        ::cont::
    end
end)

Players.PlayerRemoving:Connect(function(p)
    if espObjects[p] then
        for _,o in pairs(espObjects[p]) do o:Remove() end
        espObjects[p]=nil
    end
end)

return ESP
