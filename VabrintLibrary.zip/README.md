# Vabrint Library - ESP Module

Vabrint Library ESP is a lightweight and customizable ESP for Roblox games.

## Loading

```
loadstring(game:HttpGet("https://raw.githubusercontent.com/mrpopcat14/VabrintLibrary/main/esp.lua"))()
```

## Usage

```
ESP:SetColorMode("rgb")             # "rgb" or "custom,#RRGGBB"
ESP:SetHealthColorMode("match")     # "match" or "custom,#RRGGBB"
ESP:SetShowBoxes(true)
ESP:SetShowNames(true)
ESP:SetShowTracers(true)
ESP:SetShowHealth(true)
ESP:SetTextSize(16)
ESP:SetBoxThickness(2)
ESP:SetTracerThickness(1)
ESP:Enable()
```

## Color Modes

- `rgb`: rainbow cycling
- `custom,#RRGGBB`: static hex color

## Health Bar Modes

- `match`: matches box color
- `custom,#RRGGBB`: uses custom hex color

## Credits

- Mrpopcat14 (YouTube)
- 91yd (Discord)
